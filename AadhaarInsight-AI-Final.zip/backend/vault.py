# result storage logic placeholder
