# normalization logic placeholder
